# RoutierFleet - Monitorare semiremorci

Proiect minimal React + Vite + Tailwind. Interfața este în limba română și folosește un logo placeholder în `src/assets/logo.png`.
Înlocuiește `src/assets/logo.png` cu logo-ul real al firmei dacă-l ai.

## Pași pentru a rula (local)

1. Asigură-te că ai Node.js 18+ instalat.
2. Deschide terminal în dosarul proiectului.
3. Rulează:
   npm install
   npm run dev
4. Deschide Google Chrome la adresa afișată (de ex. http://localhost:5173)

## Observații
- Datele se salvează local în `localStorage` browser-ului (pe acel calculator).
- Pentru sincronizare între calculatoare este nevoie de backend / bază de date; pot să-l pregătesc la cerere.
