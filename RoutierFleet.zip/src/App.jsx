import React from 'react'
import MonitorareSemiremorci from './MonitorareSemiremorci'

export default function App(){
  return <MonitorareSemiremorci />
}
