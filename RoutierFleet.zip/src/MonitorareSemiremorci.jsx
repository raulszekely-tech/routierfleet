\
import React, { useEffect, useState } from "react";
import logo from "./assets/logo.png";

const STORAGE_KEY = "monitorare_semiremorci_v1";

function nowISO() {
  return new Date().toISOString();
}
function formatLocal(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return d.toLocaleString();
}
function uid() {
  return Math.random().toString(36).slice(2, 9);
}

export default function MonitorareSemiremorci() {
  const [items, setItems] = useState([]);
  const [plate, setPlate] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [locationDesc, setLocationDesc] = useState("");
  const [coords, setCoords] = useState({ lat: "", lon: "" });
  const [filter, setFilter] = useState("");
  const [showOnlyParked, setShowOnlyParked] = useState(true);

  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        setItems(JSON.parse(raw));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  function addTrailer(e) {
    e?.preventDefault();
    if (!plate.trim()) return alert("Introduceți numărul de înmatriculare.");
    const newItem = {
      id: uid(),
      plate: plate.trim().toUpperCase(),
      loaded: !!loaded,
      entry: nowISO(),
      exit: null,
      location: {
        desc: locationDesc.trim(),
        lat: coords.lat || null,
        lon: coords.lon || null,
      },
      notes: "",
    };
    setItems((s) => [newItem, ...s]);
    setPlate("");
    setLoaded(false);
    setLocationDesc("");
    setCoords({ lat: "", lon: "" });
  }

  function markExit(id) {
    const exitTime = nowISO();
    setItems((s) => s.map((it) => (it.id === id ? { ...it, exit: exitTime } : it)));
  }
  function undoExit(id) {
    setItems((s) => s.map((it) => (it.id === id ? { ...it, exit: null } : it)));
  }
  function removeItem(id) {
    if (!confirm("Ștergeți această înregistrare?")) return;
    setItems((s) => s.filter((it) => it.id !== id));
  }
  function useGeolocation() {
    if (!navigator.geolocation) {
      return alert("Geolocația nu este disponibilă în acest browser.");
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude.toString(), lon: pos.coords.longitude.toString() });
      },
      (err) => {
        alert("Eroare la obținerea geolocației: " + err.message);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }
  function exportCSV() {
    const header = ["id,plate,loaded,entry,exit,location_desc,lat,lon,notes\n"];
    const lines = items.map((it) =>
      [
        it.id,
        `"${it.plate}"`,
        it.loaded ? "Încărcată" : "Goală",
        it.entry,
        it.exit || "",
        `"${(it.location?.desc || "").replace(/"/g, '""')}"`,
        it.location?.lat || "",
        it.location?.lon || "",
        `"${(it.notes || "").replace(/"/g, '""')}"`,
      ].join(",")
    );

    const csv = header.concat(lines).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `semiremorci_export_${new Date().toISOString()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const filtered = items.filter((it) => {
    if (showOnlyParked && it.exit) return false;
    if (filter && !it.plate.includes(filter.toUpperCase())) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="mx-auto max-w-5xl">
        <header className="mb-6 flex items-center gap-4">
          <img src={logo} alt="Routier European Transport" style={{height:48}} />
          <div>
            <h1 className="text-2xl font-semibold mb-1">RoutierFleet — Monitorare semiremorci</h1>
            <p className="text-sm text-slate-600">Aplicație web locală — accesibilă din Google Chrome. Date stocate local.</p>
          </div>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <section className="lg:col-span-1 bg-white p-4 rounded-2xl shadow-sm">
            <h2 className="font-medium mb-3">Înregistrare intrare</h2>
            <form onSubmit={addTrailer} className="space-y-3">
              <div>
                <label className="block text-sm">Număr înmatriculare</label>
                <input
                  value={plate}
                  onChange={(e) => setPlate(e.target.value)}
                  className="w-full mt-1 p-2 border rounded"
                  placeholder="B 12 ABC"
                />
              </div>

              <div className="flex items-center gap-3">
                <label className="text-sm">Stare</label>
                <select value={loaded ? "loaded" : "empty"} onChange={(e) => setLoaded(e.target.value === "loaded")} className="p-2 border rounded">
                  <option value="empty">Goală</option>
                  <option value="loaded">Încărcată</option>
                </select>
              </div>

              <div>
                <label className="block text-sm">Locație (descriere)</label>
                <input value={locationDesc} onChange={(e) => setLocationDesc(e.target.value)} className="w-full mt-1 p-2 border rounded" placeholder="Ex: Curbă 5, rampa A" />
                <div className="flex gap-2 mt-2">
                  <input value={coords.lat} onChange={(e) => setCoords((c) => ({ ...c, lat: e.target.value }))} placeholder="lat" className="p-2 border rounded w-1/2" />
                  <input value={coords.lon} onChange={(e) => setCoords((c) => ({ ...c, lon: e.target.value }))} placeholder="lon" className="p-2 border rounded w-1/2" />
                </div>
                <div className="flex gap-2 mt-2">
                  <button type="button" onClick={useGeolocation} className="px-3 py-2 rounded bg-indigo-600 text-white text-sm">Folosește geolocație</button>
                  <button type="submit" className="px-3 py-2 rounded bg-green-600 text-white text-sm">Adaugă intrare</button>
                </div>
              </div>

              <div className="text-xs text-slate-500">Intrarea va primi data și ora curentă automat.</div>
            </form>

            <div className="mt-4 border-t pt-3">
              <button onClick={exportCSV} className="px-3 py-2 rounded bg-slate-800 text-white text-sm">Export CSV</button>
              <button onClick={() => { if (confirm('Resetați toate datele?')) { setItems([]); } }} className="ml-2 px-3 py-2 rounded bg-red-600 text-white text-sm">Resetare date</button>
            </div>
          </section>

          <section className="lg:col-span-2 bg-white p-4 rounded-2xl shadow-sm">
            <div className="flex justify-between items-center mb-3">
              <div className="flex gap-2">
                <input placeholder="Caută după număr" value={filter} onChange={(e) => setFilter(e.target.value)} className="p-2 border rounded" />
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={showOnlyParked} onChange={(e) => setShowOnlyParked(e.target.checked)} />
                  <span className="text-sm">Afișează doar parcate</span>
                </label>
              </div>

              <div className="text-sm text-slate-600">Total înregistrări: {items.length} — Parcate: {items.filter(it => !it.exit).length}</div>
            </div>

            <div className="space-y-3 max-h-[60vh] overflow-auto">
              {filtered.length === 0 && <div className="text-center text-slate-500 py-8">Nicio înregistrare</div>}
              {filtered.map((it) => (
                <article key={it.id} className="p-3 border rounded-lg flex justify-between items-start">
                  <div>
                    <div className="flex items-baseline gap-3">
                      <div className="text-lg font-semibold">{it.plate}</div>
                      <div className="text-xs px-2 py-1 rounded bg-slate-100">{it.loaded ? "Încărcată" : "Goală"}</div>
                      {it.exit ? <div className="text-xs ml-2 text-amber-700">Plecată</div> : <div className="text-xs ml-2 text-green-600">Parcată</div>}
                    </div>
                    <div className="text-xs text-slate-600 mt-1">Intrare: {formatLocal(it.entry)}</div>
                    <div className="text-xs text-slate-600">Ieșire: {it.exit ? formatLocal(it.exit) : "—"}</div>
                    <div className="mt-2 text-sm">Locație: {it.location?.desc || "(fără descriere)"} {it.location?.lat && it.location?.lon ? (<a className="ml-2 text-sm underline" href={`https://www.google.com/maps/search/?api=1&query=${it.location.lat},${it.location.lon}`} target="_blank" rel="noreferrer">Vezi hartă</a>) : null}</div>
                  </div>

                  <div className="flex flex-col gap-2">
                    {!it.exit ? (
                      <button onClick={() => markExit(it.id)} className="px-3 py-2 rounded bg-emerald-600 text-white text-sm">Înregistrare ieșire</button>
                    ) : (
                      <button onClick={() => undoExit(it.id)} className="px-3 py-2 rounded bg-yellow-500 text-white text-sm">Anulează ieșire</button>
                    )}
                    <button onClick={() => {
                      const newNotes = prompt('Observații pentru ' + it.plate + ' (lăsați gol pentru a păstra):', it.notes || '');
                      if (newNotes !== null) {
                        setItems((s) => s.map((x) => x.id === it.id ? { ...x, notes: newNotes } : x));
                      }
                    }} className="px-3 py-2 rounded bg-slate-200 text-sm">Adaugă/editează observație</button>
                    <button onClick={() => removeItem(it.id)} className="px-3 py-2 rounded bg-red-600 text-white text-sm">Șterge</button>
                  </div>
                </article>
              ))}
            </div>

          </section>
        </main>

        <footer className="text-xs text-slate-500 mt-6">Sugestie: pentru funcționalități complexe (raportare avansată, useri, backend centralizat) pot să extind aplicația cu server și autentificare.</footer>
      </div>
    </div>
  );
}
